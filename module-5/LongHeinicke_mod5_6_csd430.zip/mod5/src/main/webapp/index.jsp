<%--
  jessica long-heinicke 6.22.25 csd  430
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Movie Database CRUD</title>
    <style>

        body { font-family: Arial, sans-serif; margin: 40px; }
        .container { max-width: 800px; margin: 0 auto; }
        h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
        ul { list-style: none; padding: 0; }
        li { margin: 15px 0; }
        a {
            display: block;
            padding: 12px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        a:hover { background: #2980b9; }
    </style>
</head>
<body>
<div class="container">
    <h1>Movie Database CRUD Operations</h1>
    <ul>
        <li><a href="create.jsp">Add New Movie</a></li>
        <li><a href="read.jsp">View All Movies</a></li>
        <li><a href="update.jsp">Update Movie Record</a></li>
        <li><a href="delete.jsp">Delete Movie Record</a></li>
        <li><a href="dbstatus.jsp">Check Database Status</a></li>
    </ul>
</div>
</body>
</html>